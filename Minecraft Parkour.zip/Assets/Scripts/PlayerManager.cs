using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class PlayerManager : MonoBehaviour
{
    private Color platformRenderer;
    [SerializeField] private GameObject Effect1;
    [SerializeField] private GameObject Effect2;
    [Space(20)]
    [SerializeField] private Rigidbody playerRB;
    [SerializeField] private float xForce;
    [SerializeField] private GameObject StartPosition;
    //[SerializeField] private CharacterController PlayerCC;
    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Platform"))
        {
            platformRenderer = GetComponent<Renderer>().sharedMaterial.color = Random.ColorHSV();
            Instantiate(Effect1, transform.position, Quaternion.identity);
        }

        if (other.gameObject.CompareTag("Trampoline"))
        {
            playerRB.AddForce(0f,xForce,0f);
            platformRenderer = GetComponent<Renderer>().sharedMaterial.color = Random.ColorHSV();
            Instantiate(Effect2, transform.position, Quaternion.identity);
        }

        if (other.gameObject.CompareTag("GameOver"))
        {
            transform.position = StartPosition.transform.position;
        }
    }
}
